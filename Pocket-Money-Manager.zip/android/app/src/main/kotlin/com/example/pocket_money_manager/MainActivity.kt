package com.example.pocket_money_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
